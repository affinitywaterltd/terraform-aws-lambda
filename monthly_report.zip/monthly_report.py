def lambda_handler():

    print "Hello World"