def lambda_handler(request,context):

    print "Hello World"
